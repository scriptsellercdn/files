<?php

namespace OM4\WooCommerceZapier\Exception;

defined( 'ABSPATH' ) || exit;

/**
 * Exception to trigger when problems with tasks.
 */
class InvalidImplementationException extends BaseException {
}
